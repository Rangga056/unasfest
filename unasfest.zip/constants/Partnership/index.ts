export const partnership = [
    {
        index : 0,
        image : "",
        title : "",
        description : "",
        link: ""
    }
]