export const contactsData = [
    {
        index: 0,
        title: "Partnership",
        whatsApp: "https://wa.me/6282285202610",
    },
    {
        index: 1,
        title: "Media Partner",
        whatsApp: "https://wa.me/6281272545088",
    },
    {
        index: 2,
        title: "Donatur",
        whatsApp: "https://wa.me/6281293258633",
    },
    {
        index: 3,
        title: "Bazar",
        whatsApp: "https://wa.me/6285715039937",
    },
]