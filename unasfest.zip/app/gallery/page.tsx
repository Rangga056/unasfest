import Faq from "@/components/shared/Faq/Faq"

export default function Gallery(){
    return(
        // <Faq />
        <div></div>
    )
}