export interface judgesDataProps {
  judgesData: Array<{
    name: string;
    image: string;
    lastEducation: string;
    description: string;
    achievements: string[];
  }>;
}
