export interface timelinesDatasProps {
    timelines: Array<{
      title: string;
      description: string;
      month: string;
      date: string;
      year: string;
      color: string;
    }>;
  }
