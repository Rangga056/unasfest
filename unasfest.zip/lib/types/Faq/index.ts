export interface faqsDataProps {
  faqsData: Array<{
    index: number;
    quetion: string;
    answer: string;
  }>;
}
